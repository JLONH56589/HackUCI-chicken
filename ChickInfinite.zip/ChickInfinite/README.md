# HackUCI-chicken
ChickInfinity

HackUCI 2018

Creators:
Justin Lonh,
Ngan Luong,
Alan Huang,
Lee Suan,
Tyler Vo


ChickInfinity is a basic game where the player attempts to collect eggs that are being hatched by a chicken. 
This is an intense, fast-paced game that requires fast reflexes and precise mechanical skill to master. 
How close can you get to ChickInfinity? 



Our team wrote this game using Python with help from the Kivy library. We've designed this version of the game to be a functional prototype that can be enjoyed by itself, yet still has great potential for expansion in the future beyond HackUCI. Our team's vision for this game includes features such as implementation of a shop system where eggs can be exchanged for both practical and cosmetic upgrades, and expansion of animation of objects in the game. Furthermore, a premium currency may be introduced alongside the implementation of microtransactions on mobile versions of the game. Our team strongly believes that our small game has great potential. 

This game features both original art by our team and public domain assets! A special thanks to Kenney.nl for providing visual game assets. 
